# Engineering Log Book
A record of my what I attempted, what failed, what I accomplished, and the chain link generated when I archive a session.


# 17-10-2026 to 18-10-2026

### Attempted
- I attempted making automation scripts for future use during development. The goal is to be able to create a script that creates the desired shell script, assign it execute permissions, insert a shebang statement as well as adding import statements for naledi.conf below the shebang statement if the flag "--import-variables" is provided when running the script. I aliased it "mytouch" in "~/.bashrc"

- Another automation script I had tried is one that I use to run shell scripts and shell commands whose tasks require the banner to be shown in running the output. its aim is to avoid having to invoke my banner function each time it is needed to be run when running a shell script or shell command needing it. I aliased it "myrun" in "~/.bashrc"

- I tried making a shell script to automate seeding my data files. I wanted to be able to whenever necessary, be able to quickly re-seed the needed data files.

### Failures and Problems
With the feature to be able to create scripts already having the shebang statement, and naledi.conf import without hardcoding the path to naledi.conf itself was problematic. Firstly to import naledi.conf without hardcoding the path to it,  after the shebang statement, I placed the following: 

```
CURR_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$CURR_SCRIPT_DIR/../etc/naledi.conf"
```
Initially, I used the echo command and redirected the output using `>` to the created shell script. However, the variable calls in those two lines would be written into that file after being expanded out, meaning the path to naledi.conf would be written as is in the new file, resulting in a hardcoded path, which is what we want to avoid.

I tried escaping the `$` for each variable with `\`,  it did not work, I in fact got syntax error because of my bad placement of those but even when I did place them correctly, it did not work. I also tried placing the variable calls in single quotes, that did not help either.

What eventually did work was using printf with the `%s` option,  and with that I was able to preserve and write those two lines as is.

### What I accomplished
- I managed to successfully complete, test and use my automation shell scripts being my_run.sh and my_touch.sh as well use them for creating other shell script files (module shell scripts so far and the seeding shell script)

- Lastly, I achieved completing my shell script for seeding data. Although it only seeds herd_registry.dat, districts.dat and quarantine_zones.dat only so far.

#### Chain link
```
````

```
```


```
